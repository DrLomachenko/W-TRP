#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Build two comparison plots from 'results/combined_results.csv':
 - one for tests with max(runtime) <= median seconds
 - one for tests with max(runtime)  > median seconds

Styling (as per reference):
 - Original: black line with circle markers
 - Our:      green line with square markers
 - Dashed grid
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

def find_results_dir():
    roots = [Path(".").resolve(), Path("/mnt/data").resolve()]
    for r in roots:
        d = r / "results"
        if d.exists():
            return d
    d = roots[0] / "results"
    d.mkdir(parents=True, exist_ok=True)
    return d

def plot_split(df: pd.DataFrame, out_path: Path, title: str):
    # sort by Original runtime (or max) to mimic "Sorted Test Cases"
    df = df.copy()
    df["runtime_max"] = df[["millis_original","millis_our"]].max(axis=1)  # Исправлено
    df_sorted = df.sort_values("runtime_max").reset_index(drop=True)
    x = range(1, len(df_sorted)+1)

    plt.figure(figsize=(10,4))
    # Original: black with circle markers
    plt.plot(x, df_sorted["millis_original"].values,  # Исправлено
             marker='o', linewidth=1, color='black', label="Original")
    # Our: green with square markers
    plt.plot(x, df_sorted["millis_our"].values,  # Исправлено
             marker='s', linewidth=1, color='green', label="Our")

    plt.title(title)
    plt.xlabel("Sorted Test Cases")
    plt.ylabel("CPU Time (millis)")
    plt.legend()
    # dashed grid like reference
    plt.grid(True, which='both', linestyle='--', linewidth=0.5, alpha=0.7)
    plt.tight_layout()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close()

def main():
    results_dir = find_results_dir()
    src = results_dir / "combined_results.csv"
    if not src.exists():
        raise FileNotFoundError(f"Cannot find {src}")
    df = pd.read_csv(src)

    required = ["test","millis_original","millis_our"]  # Исправлено
    for col in required:
        if col not in df.columns:
            raise ValueError(f"Column '{col}' not found in {src.name}")

    # Calculate dynamic threshold as median of max runtime
    df["runtime_max"] = df[["millis_original","millis_our"]].max(axis=1)  # Исправлено
    threshold = df["runtime_max"].median()
    
    print(f"[plot] dynamic threshold (median): {threshold:.2f} millis")
    
    df_under = df[df["runtime_max"] <= threshold].copy()
    df_over  = df[df["runtime_max"] >  threshold].copy()

    if not df_under.empty:
        plot_split(df_under, results_dir / "comparison_under_median.png",
                   f"Original vs Our — Runtime ≤ {threshold:.1f}s (median)")
    if not df_over.empty:
        plot_split(df_over,  results_dir / "comparison_over_median.png",
                   f"Original vs Our — Runtime > {threshold:.1f}s (median)")

    print("[plot] written:",
          (results_dir / "comparison_under_median.png"),
          (results_dir / "comparison_over_median.png"))

if __name__ == "__main__":
    main()
