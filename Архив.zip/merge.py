#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Hardcoded merger for tool-switching results (no CLI args).
Reads two CSVs from the 'results' folder:
  - results_for_original.csv
  - results_for_our.csv
Keeps only common tests and writes:
  - results/combined_results.csv
  - results/combined_results_grouped.csv (aggregated by N,M,C)

Output columns:
  test, N, M, C, total_cost_original, total_cost_our, seconds_original, seconds_our
"""

from pathlib import Path
import pandas as pd

# ---- Hardcoded paths ----
CANDIDATE_ROOTS = [Path(".").resolve(), Path("/mnt/data").resolve()]
INPUT_ORIG_NAME = "resultsOriginal.csv"
INPUT_OUR_NAME  = "resultsOur.csv"
OUTPUT_NAME     = "combined_results.csv"
OUTPUT_GROUPED_NAME = "combined_results_grouped.csv"

def find_results_dir():
    for root in CANDIDATE_ROOTS:
        res = root / "results"
        if res.exists():
            return res
    # If none exist, create under the first root
    res = CANDIDATE_ROOTS[0] / "results"
    res.mkdir(parents=True, exist_ok=True)
    return res

def norm_cols(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip() for c in df.columns]
    return df

def main():
    results_dir = find_results_dir()
    orig_csv = results_dir / INPUT_ORIG_NAME
    our_csv  = results_dir / INPUT_OUR_NAME
    out_csv  = results_dir / OUTPUT_NAME
    out_grouped_csv = results_dir / OUTPUT_GROUPED_NAME

    if not orig_csv.exists() or not our_csv.exists():
        raise FileNotFoundError(f"Input CSV not found. Expected:\n  {orig_csv}\n  {our_csv}")

    orig = norm_cols(pd.read_csv(orig_csv))
    our  = norm_cols(pd.read_csv(our_csv))

    # Rename to avoid collisions after merge
    orig_ren = orig.rename(columns={
        "total_cost": "total_cost_original",
        "millis": "millis_original",  # Изменено с millis на seconds
        "N": "N_orig", "M": "M_orig", "C": "C_orig",
    })
    our_ren = our.rename(columns={
        "total_cost": "total_cost_our",
        "millis": "millis_our",  # Изменено с millis на seconds
        "N": "N_our", "M": "M_our", "C": "C_our",
    })

    # Inner join on 'test' (only common tests)
    merged = pd.merge(orig_ren, our_ren, on="test", how="inner", validate="one_to_one")

    # Harmonize N,M,C (prefer original's values; drop split cols)
    for col in ["N", "M", "C"]:
        co = f"{col}_orig"
        cu = f"{col}_our"
        if co in merged.columns and cu in merged.columns:
            merged[col] = merged[co]
            merged.drop(columns=[co, cu], inplace=True)
        elif co in merged.columns:
            merged[col] = merged[co]; merged.drop(columns=[co], inplace=True)
        elif cu in merged.columns:
            merged[col] = merged[cu]; merged.drop(columns=[cu], inplace=True)
        else:
            merged[col] = None  # just in case

    # Final column order (без cost_match / speedup)
    cols = [
        "test", "N", "M", "C",
        "total_cost_original", "total_cost_our",
        "millis_original", "millis_our",  # Изменено с millis на seconds
    ]
    cols = [c for c in cols if c in merged.columns]
    merged = merged[cols].sort_values("test").reset_index(drop=True)

    out_csv.parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(out_csv, index=False)

    print(f"[merge] rows={len(merged)}")
    print(f"[merge] written: {out_csv}")

    # Create grouped version aggregated by (N, M, C)
    if all(col in merged.columns for col in ["N", "M", "C"]):
        # Group by N, M, C and calculate mean values
        grouped = merged.groupby(["N", "M", "C"]).agg({
            "total_cost_original": "mean",
            "total_cost_our": "mean", 
            "millis_original": "mean",  # Изменено с millis на seconds
            "millis_our": "mean",      # Изменено с millis на seconds
            "test": "count"  # number of tests in each group
        }).reset_index()
        
        # Rename the count column and add group index
        grouped = grouped.rename(columns={"test": "test_count"})
        grouped.insert(0, "group_id", range(1, len(grouped) + 1))
        
        # Rename time columns to indicate they are averages
        grouped = grouped.rename(columns={
            "millis_original": "avg_millis_original",  # Изменено с millis на seconds
            "millis_our": "avg_millis_our"            # Изменено с millis на seconds
        })
        
        # Since both algorithms should give the same answer, use the average cost
        # This represents the average solution cost across all tests in the group
        grouped["avg_total_cost"] = (grouped["total_cost_original"] + grouped["total_cost_our"]) / 2
        
        # Drop the separate cost columns
        grouped = grouped.drop(columns=["total_cost_original", "total_cost_our"])
        
        # Round numeric columns for better readability
        numeric_cols = ["avg_total_cost", "avg_millis_original", "avg_millis_our"]
        for col in numeric_cols:
            if col in grouped.columns:
                grouped[col] = grouped[col].round(4)
        
        # Reorder columns
        final_cols = ["group_id", "N", "M", "C", "test_count", "avg_total_cost", "avg_millis_original", "avg_millis_our"]
        grouped = grouped[final_cols]
        
        # Save grouped results
        grouped.to_csv(out_grouped_csv, index=False)
        print(f"[merge] grouped rows={len(grouped)}")
        print(f"[merge] written: {out_grouped_csv}")
    else:
        print("[merge] Warning: Cannot create grouped version - missing N, M, or C columns")

if __name__ == "__main__":
    main()
