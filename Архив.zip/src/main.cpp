#include <iostream>
#include <filesystem>
#include <vector>
#include <string>
#include <fstream>
#include <chrono>
#include <iomanip>
#include <memory>

#include "Instance.h"
#include "DAG.h"
#include "IBuildGraph.h"
#include "BuilderPF.h"
#include "BuilderLC.h"

namespace fs = std::filesystem;

static std::vector<std::string> get_test_files(const std::string& directory) {
    std::vector<std::string> files;
    for (const auto& entry : fs::directory_iterator(directory)) {
        if (entry.is_regular_file() && entry.path().extension() == ".txt") {
            files.push_back(entry.path().string());
        }
    }
    std::sort(files.begin(), files.end());
    return files;
}

static void run_pipeline(const std::vector<std::string>& test_files,
                         const IBuildGraph& builder,
                         const std::string& csv_path) {
    std::ofstream csv(csv_path);
    csv << "builder,test,N,M,C,total_cost,millis\n";

    for (const auto& test_file : test_files) {
        try {
            TestInstance instance = TestInstance::load_from_file(test_file);

            auto t0 = std::chrono::high_resolution_clock::now();
            DAG dag = builder.build_from_instance(instance);
            int total_cost = dag.compute_max_flow_min_cost();
            auto t1 = std::chrono::high_resolution_clock::now();

            double ms = std::chrono::duration_cast<std::chrono::microseconds>(t1 - t0).count() / 1000.0;
            csv << builder.name() << ","
                << fs::path(test_file).filename().string() << ","
                << instance.N << "," << instance.M << "," << instance.C << ","
                << total_cost << ","
                << std::fixed << std::setprecision(3) << ms << "\n";

            std::cout << "[" << builder.name() << "] "
                      << fs::path(test_file).filename().string()
                      << " -> cost=" << total_cost << ", time=" << ms << " ms\n";
        } catch (const std::exception& e) {
            std::cerr << "[" << builder.name() << "] ERROR " << test_file << ": " << e.what() << "\n";
        }
    }
    std::cout << "Saved: " << csv_path << "\n";
}

int main() {
    std::cout << "=== Tool Switching Problem (PF vs LC) ===\n";

    const std::string tests_dir   = "tests_txt";
    const std::string results_dir = "results";
    std::filesystem::create_directory(results_dir);

    auto tests = get_test_files(tests_dir);

    PFBuilder pf;
    LCBuilder lc;

    run_pipeline(tests, pf, results_dir + "/resultsOriginal.csv");
    run_pipeline(tests, lc, results_dir + "/resultsOur.csv");

    return 0;
}
