#pragma once
#include <vector>
#include <memory>
#include <limits>
#include <stdexcept>

class DAG {
public:
    // === Публичный API (не меняли) ===
    int  add_vertex();
    void add_edge(int from, int to, int weight = 0, int capacity = 0);
    void set_source(int source);
    void set_sink(int sink);

    // Возвращает сумму стоимостей по исходным рёбрам с weight>=0 в оптимальном решении
    int  compute_max_flow_min_cost();

    // Проверка: входной граф (по исходным прямым дугам) — DAG?
    bool is_acyclic() const;

private:
    // ====== Внутренняя модель дуги резидуальной сети ======
    struct Arc {
        int from, to;
        virtual ~Arc() = default;
        virtual int  residual_cap() const = 0;     // доступная емкость в резидуалке
        virtual long long cost()  const = 0;       // стоимость дуги (не редуцированная)
        virtual void augment(int add) = 0;         // протолкнуть 'add' вдоль дуги
        virtual bool is_forward() const = 0;       // прямая ли (исходная) дуга
        // Для удобства восстановления пути:
        int tail() const { return from; }
        int head() const { return to;   }
    };

    struct ForwardArc;  // объявим, нужен в BackwardArc
    struct BackwardArc : Arc {
        ForwardArc* mate; // ссылка на соответствующую прямую дугу
        BackwardArc(int u, int v, ForwardArc* f) : mate(f) { from=u; to=v; }
        int  residual_cap() const override;    // = mate->flow
        long long cost()  const override;      // = - mate->weight
        void augment(int add) override;        // уменьшает mate->flow
        bool is_forward() const override { return false; }
    };

    struct ForwardArc : Arc {
        int capacity = 0;
        int flow     = 0;
        int weight   = 0;          // вес исходного ребра (может быть <0 для -K)
        BackwardArc* mate = nullptr;
        ForwardArc(int u, int v, int cap, int w) : capacity(cap), weight(w) { from=u; to=v; }
        int  residual_cap() const override;    // = capacity - flow
        long long cost()  const override;      // = weight
        void augment(int add) override;        // увеличивает flow
        bool is_forward() const override { return true; }
    };

private:
    // Внутреннее хранение резидуальной сети
    std::vector<std::vector<Arc*>> g_;              // смежность по вершинам
    std::vector<std::unique_ptr<Arc>> storage_;     // владение объектами дуг

    // Вспомогательные методы
    void add_arc_pair_(int u, int v, int cap, int w);
    bool has_cycle_dfs_(int v, std::vector<int>& vis) const;

    // Потенциалы Джонсона — для Дейкстры по редуцированным стоимостям
    void init_potentials_by_topo_(std::vector<long long>& pi) const;
    bool topological_sort_forward_(std::vector<int>& order) const;

public:
    // Состояние графа (как ты просил оставить в классе)
    int vertex_count = 0;
    int source_index = -1;
    int sink_index   = -1;
};
