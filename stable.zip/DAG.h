#ifndef DAG_HPP
#define DAG_HPP

#include <vector>
#include <queue>
#include <climits>
#include <stdexcept>
#include <algorithm>

struct Edge {
    int from;           // индекс исходной вершины
    int to;             // индекс целевой вершины
    int weight;         // вес ребра
    int capacity;       // ёмкость ребра (пропускная способность)
    int flow = 0;       // текущий поток через ребро (по умолчанию 0)

    Edge(int f, int t, int w = 0, int cap = 0);

    // Сравнение ТОЛЬКО по весам
    bool operator<(const Edge& other) const;
};

class DAG {
public:
    int vertex_count = 0;                      // счётчик числа вершин
    std::vector<std::vector<Edge>> edges;      // все ребра по индексу вершины (исходящие)
    int source_index = -1;                     // индекс истока
    int sink_index = -1;                       // индекс стока

public:
    // Добавление вершины - возвращает индекс новой вершины
    int add_vertex();

    // Добавление ребра
    void add_edge(int from, int to, int weight = 0, int capacity = 0);

    // Методы для установки истока и стока
    void set_source(int source);
    void set_sink(int sink);

    void print();

    // Алгоритмы поиска пути
    std::vector<int> dijkstra_shortest_path(int start) const;
    std::vector<int> dag_shortest_path_with_negatives(int start) const;

    // Потоковые алгоритмы
    int compute_max_flow_min_cost();

    // Топологическая сортировка
    std::vector<int> topological_sort() const;

    // Валидация DAG
    bool is_acyclic() const;

private:
    // Вспомогательные методы для потоковых алгоритмов
    bool find_augmenting_path_dag(std::vector<int>& parent, std::vector<int>& distance) const;
    int compute_residual_capacity(int from, int to) const;
    void update_flow_along_path(const std::vector<int>& parent, int path_flow);

    // Вспомогательные методы для проверки циклов
    bool has_cycle_dfs(int vertex, std::vector<int>& visited) const;
};

#endif // DAG_HPP