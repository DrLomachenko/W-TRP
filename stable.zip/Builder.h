#ifndef BUILDER_HPP
#define BUILDER_HPP

#include "DAG.h"
#include "Instance.h"

class GraphBuilder {
public:
    static DAG build_from_instance(const TestInstance& instance, int K = 10000);

};

#endif // BUILDER_HPP