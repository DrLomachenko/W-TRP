import random
import os
import shutil
from typing import List, Tuple, Dict
from collections import deque
count_tests_per_group = 10
class DAGTestGenerator:
    def __init__(self, seed=42):
        random.seed(seed)
        self.tests = []
    
    def generate_tool_switching_dag(self, num_jobs: int, num_tools: int, magazine_capacity: int) -> Dict:
        """Генерация DAG как в статье Privault и Finke для задачи смены инструментов"""
        # Генерируем требования инструментов для каждого job
        job_tools = []
        for job_id in range(num_jobs):
            num_tools_in_job = random.randint(1, min(5, magazine_capacity))
            tools = random.sample(range(num_tools), num_tools_in_job)
            job_tools.append(tools)
        
        # Строим DAG по схеме из статьи
        vertices = []
        edges = []
        
        # Уровень 1: начальная конфигурация магазина
        initial_slots = list(range(magazine_capacity))
        vertices.extend(initial_slots)
        current_vertex = magazine_capacity
        
        # Уровень 2: запросы инструментов по job'ам
        request_vertices = []
        for job_id, tools in enumerate(job_tools):
            job_vertices = list(range(current_vertex, current_vertex + len(tools)))
            request_vertices.append(job_vertices)
            vertices.extend(job_vertices)
            current_vertex += len(tools)
            
            # Соединяем начальные слоты с первым job'ом
            if job_id == 0:
                for slot in initial_slots:
                    for tool_idx, tool_vertex in enumerate(job_vertices):
                        weight = random.randint(1, 5)  # Время установки инструмента
                        capacity = 1
                        edges.append((slot, tool_vertex, weight, capacity))
        
        # Уровень 3: копии вершин запросов
        copy_vertices = []
        for job_vertices in request_vertices:
            copy_job_vertices = list(range(current_vertex, current_vertex + len(job_vertices)))
            copy_vertices.append(copy_job_vertices)
            vertices.extend(copy_job_vertices)
            current_vertex += len(job_vertices)
            
            # Горизонтальные ребра с большим отрицательным весом (как в статье)
            for orig, copy in zip(job_vertices, copy_job_vertices):
                edges.append((orig, copy, -1000, 1))  # Большой отрицательный вес
        
        # Ребра между копиями и следующими запросами
        for i in range(len(copy_vertices) - 1):
            current_copies = copy_vertices[i]
            next_requests = request_vertices[i + 1]
            
            for copy_vertex in current_copies:
                for request_vertex in next_requests:
                    weight = random.randint(1, 5)  # Время смены инструмента
                    capacity = 1
                    edges.append((copy_vertex, request_vertex, weight, capacity))
        
        # Добавляем сток
        sink = current_vertex
        vertices.append(sink)
        current_vertex += 1
        
        # Соединяем последние копии со стоком
        for copy_vertex in copy_vertices[-1]:
            edges.append((copy_vertex, sink, 0, 1))
        
        # Добавляем источник
        source = current_vertex
        vertices.append(source)
        
        # Соединяем источник с начальными слотами
        for slot in initial_slots:
            edges.append((source, slot, 0, 1))
        
        # Вычисляем ожидаемый поток с помощью Bellman-Ford (эталонный алгоритм)
        expected_flow, expected_cost = self.compute_max_flow_min_cost_bellman_ford(
            vertices, edges, source, sink
        )
        
        return {
            "num_vertices": len(vertices),
            "edges": edges,
            "source": source,
            "sink": sink,
            "expected_max_flow": expected_flow,
            "expected_min_cost": expected_cost,
            "description": f"Tool switching DAG: {num_jobs} jobs, {num_tools} tools, capacity {magazine_capacity}",
            "job_tools": job_tools,
            "magazine_capacity": magazine_capacity
        }
    
    def compute_max_flow_min_cost_bellman_ford(self, vertices, edges, source, sink):
        """Вычисление min-cost max-flow с помощью Bellman-Ford (эталонный алгоритм)"""
        num_vertices = len(vertices)
        
        # Создаем матрицы пропускных способностей и стоимостей
        capacity = [[0] * num_vertices for _ in range(num_vertices)]
        cost = [[0] * num_vertices for _ in range(num_vertices)]
        flow = [[0] * num_vertices for _ in range(num_vertices)]
        
        for u, v, w, cap in edges:
            capacity[u][v] = cap
            cost[u][v] = w
            cost[v][u] = -w  # Обратные ребра
        
        max_flow = 0
        total_cost = 0
        
        while True:
            # Bellman-Ford для поиска увеличивающего пути
            dist = [float('inf')] * num_vertices
            parent = [-1] * num_vertices
            dist[source] = 0
            
            # Релаксация всех ребер V-1 раз
            for _ in range(num_vertices - 1):
                updated = False
                for u in range(num_vertices):
                    if dist[u] == float('inf'):
                        continue
                    for v in range(num_vertices):
                        # Прямые ребра
                        if capacity[u][v] > flow[u][v] and dist[v] > dist[u] + cost[u][v]:
                            dist[v] = dist[u] + cost[u][v]
                            parent[v] = u
                            updated = True
                        # Обратные ребра
                        if flow[v][u] > 0 and dist[v] > dist[u] - cost[v][u]:
                            dist[v] = dist[u] - cost[v][u]
                            parent[v] = u
                            updated = True
                if not updated:
                    break
            
            if dist[sink] == float('inf'):
                break
            
            # Находим минимальную пропускную способность на пути
            path_flow = float('inf')
            v = sink
            while v != source:
                u = parent[v]
                if capacity[u][v] > flow[u][v]:  # Прямое ребро
                    path_flow = min(path_flow, capacity[u][v] - flow[u][v])
                else:  # Обратное ребро
                    path_flow = min(path_flow, flow[v][u])
                v = u
            
            # Обновляем поток
            v = sink
            path_cost = 0
            while v != source:
                u = parent[v]
                if capacity[u][v] > flow[u][v]:  # Прямое ребро
                    flow[u][v] += path_flow
                    path_cost += path_flow * cost[u][v]
                else:  # Обратное ребро
                    flow[v][u] -= path_flow
                    path_cost -= path_flow * cost[v][u]  # Стоимость обратного ребра отрицательная
                v = u
            
            max_flow += path_flow
            total_cost += path_cost
        
        return max_flow, total_cost
    
    def generate_multiple_tests(self):
        """Генерация набора тестов разной сложности со случайными параметрами"""
        test_cases = []
        
        # Простые тесты (маленькие магазины, мало jobs)
        print("Генерация простых тестов...")
        for i in range(count_tests_per_group):
            num_jobs = random.randint(3, 6)
            num_tools = random.randint(5, 10)
            capacity = random.randint(2, 4)
            test_cases.append(self.generate_tool_switching_dag(num_jobs, num_tools, capacity))
            print(f"  Простой тест {i+1}: {num_jobs} jobs, {num_tools} tools, capacity {capacity}")
        
        # Средние тесты
        print("Генерация средних тестов...")
        for i in range(count_tests_per_group):
            num_jobs = random.randint(7, 12)
            num_tools = random.randint(11, 20)
            capacity = random.randint(5, 8)
            test_cases.append(self.generate_tool_switching_dag(num_jobs, num_tools, capacity))
            print(f"  Средний тест {i+1}: {num_jobs} jobs, {num_tools} tools, capacity {capacity}")
        
        # Сложные тесты
        print("Генерация сложных тестов...")
        for i in range(count_tests_per_group):
            num_jobs = random.randint(13, 20)
            num_tools = random.randint(21, 35)
            capacity = random.randint(9, 15)
            test_cases.append(self.generate_tool_switching_dag(num_jobs, num_tools, capacity))
            print(f"  Сложный тест {i+1}: {num_jobs} jobs, {num_tools} tools, capacity {capacity}")
        
        # Очень сложные тесты (для проверки производительности)
        print("Генерация очень сложных тестов...")
        for i in range(count_tests_per_group):
            num_jobs = random.randint(20, 30)
            num_tools = random.randint(30, 50)
            capacity = random.randint(15, 25)
            test_cases.append(self.generate_tool_switching_dag(num_jobs, num_tools, capacity))
            print(f"  Очень сложный тест {i+1}: {num_jobs} jobs, {num_tools} tools, capacity {capacity}")
        
        self.tests = test_cases
        return test_cases
    
    def save_tests_as_txt(self, output_dir: str = "tests"):
        """Сохранение тестов в формате txt в указанную папку"""
        
        # Очищаем и создаем папку
        if os.path.exists(output_dir):
            shutil.rmtree(output_dir)
        os.makedirs(output_dir)
        
        for i, test in enumerate(self.tests):
            filename = os.path.join(output_dir, f"test_{i:02d}.txt")
            
            with open(filename, 'w', encoding='utf-8') as f:
                # Записываем заголовок
                f.write(f"# Test {i}: {test['description']}\n")
                f.write(f"# Expected max flow: {test['expected_max_flow']}\n")
                f.write(f"# Expected min cost: {test['expected_min_cost']}\n")
                f.write("# Format: num_vertices source sink\n")
                f.write("# Then edges: from to weight capacity\n")
                f.write("\n")
                
                # Записываем основные параметры
                f.write(f"{test['num_vertices']} {test['source']} {test['sink']}\n")
                
                # Записываем все ребра
                for u, v, weight, capacity in test['edges']:
                    f.write(f"{u} {v} {weight} {capacity}\n")
            
            print(f"Создан тест: {filename}")
        
        # Создаем файл с информацией о всех тестах
        info_file = os.path.join(output_dir, "test_info.txt")
        with open(info_file, 'w', encoding='utf-8') as f:
            f.write("=== Tool Switching DAG Tests Information ===\n\n")
            for i, test in enumerate(self.tests):
                f.write(f"Test {i:02d}:\n")
                f.write(f"  Description: {test['description']}\n")
                f.write(f"  Vertices: {test['num_vertices']}\n")
                f.write(f"  Edges: {len(test['edges'])}\n")
                f.write(f"  Source: {test['source']}, Sink: {test['sink']}\n")
                f.write(f"  Expected max flow: {test['expected_max_flow']}\n")
                f.write(f"  Expected min cost: {test['expected_min_cost']}\n")
                if 'job_tools' in test:
                    f.write(f"  Jobs: {len(test['job_tools'])}, Tools: {max(max(tools) for tools in test['job_tools']) + 1}, Capacity: {test['magazine_capacity']}\n")
                f.write(f"  File: test_{i:02d}.txt\n")
                f.write("\n")
        
        print(f"\nСгенерировано {len(self.tests)} тестов в папке '{output_dir}'")
        print(f"Информация о тестах сохранена в: {info_file}")

def main():
    generator = DAGTestGenerator()
    
    # Генерируем тесты
    print("Генерация Tool Switching DAG тестов...")
    tests = generator.generate_multiple_tests()
    
    # Сохраняем тесты в папку tests
    print("Сохранение тестов в формате txt...")
    generator.save_tests_as_txt("tests")
    
    # Выводим краткую информацию
    print(f"\n=== Сводка ===")
    print(f"Всего тестов: {len(tests)}")
    print(f"Папка с тестами: tests/")
    print(f"Тип тестов: Tool Switching DAG (как в статье Privault и Finke)")
    print(f"Ответы вычислены с помощью Bellman-Ford (эталонный алгоритм)")

if __name__ == "__main__":
    main()
