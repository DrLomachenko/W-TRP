#include "DAG.h"
#include <functional>
#include <iostream>

// Реализация методов структуры Edge
Edge::Edge(int f, int t, int w, int cap)
        : from(f), to(t), weight(w), capacity(cap), flow(0) {}

bool Edge::operator<(const Edge& other) const {
    return weight < other.weight;
}

// Реализация методов класса DAG
int DAG::add_vertex() {
    edges.push_back(std::vector<Edge>());  // добавляем пустой вектор рёбер
    return vertex_count++;                  // возвращаем текущий индекс и увеличиваем счётчик
}

void DAG::add_edge(int from, int to, int weight, int capacity) {
    // Проверка валидности индексов
    if (from < 0 || from >= vertex_count) {
        throw std::out_of_range("Индекс исходной вершины невалиден");
    }
    if (to < 0 || to >= vertex_count) {
        throw std::out_of_range("Индекс целевой вершины невалиден");
    }

    // Создаем ребро и добавляем в список смежности
    Edge new_edge(from, to, weight, capacity);
    edges[from].push_back(new_edge);
}

void DAG::set_source(int source) {
    if (source < 0 || source >= vertex_count) {
        throw std::out_of_range("Индекс истока невалиден");
    }
    source_index = source;
}

void DAG::set_sink(int sink) {
    if (sink < 0 || sink >= vertex_count) {
        throw std::out_of_range("Индекс стока невалиден");
    }
    sink_index = sink;
}

std::vector<int> DAG::topological_sort() const {
    std::vector<int> in_degree(vertex_count, 0);

    // Вычисляем полустепень захода для каждой вершины
    for (int u = 0; u < vertex_count; ++u) {
        for (const Edge& edge : edges[u]) {
            in_degree[edge.to]++;
        }
    }

    std::queue<int> q;
    std::vector<int> topo_order;
    topo_order.reserve(vertex_count);

    // Добавляем вершины с нулевой полустепенью захода
    for (int i = 0; i < vertex_count; ++i) {
        if (in_degree[i] == 0) {
            q.push(i);
        }
    }

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        topo_order.push_back(u);

        // Уменьшаем полустепень захода для всех соседей
        for (const Edge& edge : edges[u]) {
            int v = edge.to;
            in_degree[v]--;
            if (in_degree[v] == 0) {
                q.push(v);
            }
        }
    }

    // Проверяем, что все вершины были обработаны (граф ациклический)
    if (topo_order.size() != vertex_count) {
        throw std::logic_error("Граф содержит циклы - не является DAG");
    }

    return topo_order;
}

std::vector<int> DAG::dag_shortest_path_with_negatives(int start) const {
    if (start < 0 || start >= vertex_count) {
        throw std::out_of_range("Стартовый индекс невалиден");
    }

    std::vector<int> topo_order = topological_sort();
    std::vector<int> dist(vertex_count, INT_MAX);
    dist[start] = 0;

    // Проходим по вершинам в топологическом порядке
    for (int u : topo_order) {
        if (dist[u] != INT_MAX) {
            for (const Edge& edge : edges[u]) {
                int v = edge.to;
                // Учитываем только рёбра с остаточной пропускной способностью
                if (edge.flow < edge.capacity) {
                    if (dist[v] > dist[u] + edge.weight) {
                        dist[v] = dist[u] + edge.weight;
                    }
                }
            }
        }
    }

    return dist;
}
void DAG::print()  {
    return;
    std::cout << "Сеть (список рёбер):" << std::endl;
    std::cout << "(from, to, weight, capacity, flow)" << std::endl;

    for (int u = 0; u < vertex_count; ++u) {
        for (const Edge& edge : edges[u]) {
            std::cout << "(" << edge.from << ", " << edge.to
                      << ", " << edge.weight
                      << ", " << edge.capacity
                      << ", " << edge.flow << ")" << std::endl;
        }
    }

    if (source_index != -1 && sink_index != -1) {
        std::cout << "Исток: " << source_index << ", Сток: " << sink_index << std::endl;
    }
}

bool DAG::find_augmenting_path_dag(std::vector<int>& parent, std::vector<int>& distance) const {
    std::vector<int> topo_order = topological_sort();
    distance.assign(vertex_count, INT_MAX);
    parent.assign(vertex_count, -1);

    distance[source_index] = 0;

    // Проходим по вершинам в топологическом порядке
    for (int u : topo_order) {
        if (distance[u] != INT_MAX) {
            for (const Edge& edge : edges[u]) {
                int v = edge.to;
                // Проверяем остаточную пропускную способность
                if (edge.flow < edge.capacity) {
                    int new_dist = distance[u] + edge.weight;
                    if (distance[v] > new_dist) {
                        distance[v] = new_dist;
                        parent[v] = u;
                    }
                }
            }
        }
    }

    return distance[sink_index] != INT_MAX;
}

int DAG::compute_residual_capacity(int from, int to) const {
    for (const Edge& edge : edges[from]) {
        if (edge.to == to) {
            return edge.capacity - edge.flow;
        }
    }
    return 0;
}

void DAG::update_flow_along_path(const std::vector<int>& parent, int path_flow) {
    for (int v = sink_index; v != source_index; v = parent[v]) {
        int u = parent[v];

        // Находим соответствующее ребро и обновляем поток
        for (Edge& edge : edges[u]) {
            if (edge.to == v) {
                edge.flow += path_flow;
                break;
            }
        }
    }
}

int DAG::compute_max_flow_min_cost() {
    if (source_index == -1 || sink_index == -1) {
        throw std::logic_error("Исток и/или сток не установлены");
    }
    if (!is_acyclic()) {
        throw std::logic_error("Граф содержит циклы - алгоритм требует DAG на входе");
    }

    const int N = vertex_count;
    using ll = long long;
    const ll INF = (1LL << 60);

    std::vector<ll> pi(N, 0);

    struct REdge {
        int to, rev;
        int cap;
        ll  cost;
        int u, idx;   // ссылка на edges[u][idx]
        int dir;      // +1 — прямое исходное ребро, -1 — обратное к нему
    };
    std::vector<std::vector<REdge>> G(N);

    auto add_redge = [&](int u, int v, int cap, ll cost, int ou, int oidx, int dir) {
        REdge a{v, (int)G[v].size(), cap,  cost, ou, oidx, dir};
        REdge b{u, (int)G[u].size(), 0,   -cost, ou, oidx, -dir};
        G[u].push_back(a);
        G[v].push_back(b);
    };

    auto rebuild_residual = [&]() {
        G.assign(N, {});
        for (int u = 0; u < N; ++u) {
            for (int i = 0; i < (int)edges[u].size(); ++i) {
                const Edge& e = edges[u][i];
                int rem = e.capacity - e.flow;
                if (rem > 0)  add_redge(u, e.to, rem,  (ll)e.weight,  u, i, +1);
                if (e.flow > 0) add_redge(e.to, u, e.flow, -(ll)e.weight, u, i, -1);
            }
        }
    };

    int max_flow = 0;
    ll result_cost = 0;   // ★ то, что вернём: сумма стоимостей по исходным рёбрам с weight >= 0

    std::vector<ll> dist(N);
    std::vector<int> pv_v(N), pv_e(N);

    while (true) {
        rebuild_residual();

        std::fill(dist.begin(), dist.end(), INF);
        dist[source_index] = 0;

        using P = std::pair<ll,int>;
        std::priority_queue<P, std::vector<P>, std::greater<P>> pq;
        pq.push({0, source_index});

        while (!pq.empty()) {
            auto [d, u] = pq.top(); pq.pop();
            if (d != dist[u]) continue;
            for (int i = 0; i < (int)G[u].size(); ++i) {
                const REdge& e = G[u][i];
                if (e.cap <= 0) continue;
                ll nd = d + e.cost + pi[u] - pi[e.to];
                if (nd < dist[e.to]) {
                    dist[e.to] = nd;
                    pv_v[e.to] = u;
                    pv_e[e.to] = i;
                    pq.push({nd, e.to});
                }
            }
        }

        if (dist[sink_index] == INF) break;

        for (int v = 0; v < N; ++v)
            if (dist[v] < INF) pi[v] += dist[v];

        int add = INT_MAX;
        for (int v = sink_index; v != source_index; v = pv_v[v]) {
            const REdge& e = G[pv_v[v]][pv_e[v]];
            add = std::min(add, e.cap);
        }

        // проталкиваем и накапливаем ТОЛЬКО неотрицательные исходные стоимости
        for (int v = sink_index; v != source_index; v = pv_v[v]) {
            int u = pv_v[v];
            REdge &e  = G[u][pv_e[v]];
            REdge &er = G[v][e.rev];

            e.cap  -= add;
            er.cap += add;

            Edge &orig = edges[e.u][e.idx];
            if (e.dir == +1) {
                orig.flow += add;
                if (orig.weight >= 0) {                // ★ учитываем только неотрицательные исходные
                    result_cost += 1LL * add * orig.weight;
                }
            } else {
                // обратная дуга "откатывает" поток
                orig.flow -= add;
                if (orig.weight >= 0) {
                    result_cost -= 1LL * add * orig.weight;
                }
            }
        }

        max_flow += add;
    }

    // Возвращаем целевое значение "как в статье" при твоём упрощении стоимости:
    // сумму стоимостей переключений по исходным рёбрам с weight >= 0
    if (result_cost > (ll)std::numeric_limits<int>::max()
        || result_cost < (ll)std::numeric_limits<int>::min()) {
        throw std::overflow_error("Результат не помещается в int");
    }
    return (int)result_cost;
}




bool DAG::is_acyclic() const {
    std::vector<int> visited(vertex_count, 0); // 0 - не посещена, 1 - в процессе, 2 - обработана

    for (int i = 0; i < vertex_count; ++i) {
        if (visited[i] == 0) {
            if (has_cycle_dfs(i, visited)) {
                return false;
            }
        }
    }
    return true;
}

bool DAG::has_cycle_dfs(int vertex, std::vector<int>& visited) const {
    visited[vertex] = 1; // помечаем как посещаемую

    for (const Edge& edge : edges[vertex]) {
        int neighbor = edge.to;
        if (visited[neighbor] == 0) {
            if (has_cycle_dfs(neighbor, visited)) {
                return true;
            }
        } else if (visited[neighbor] == 1) {
            return true; // цикл найден
        }
    }

    visited[vertex] = 2; // помечаем как полностью обработанную
    return false;
}

std::vector<int> DAG::dijkstra_shortest_path(int start) const {
    if (start < 0 || start >= vertex_count) {
        throw std::out_of_range("Стартовый индекс невалиден");
    }

    std::vector<int> dist(vertex_count, INT_MAX);
    dist[start] = 0;

    using Pair = std::pair<int, int>; // (distance, node)
    std::priority_queue<Pair, std::vector<Pair>, std::greater<Pair>> pq;
    pq.push({0, start});

    while (!pq.empty()) {
        int u = pq.top().second;
        int current_dist = pq.top().first;
        pq.pop();

        if (current_dist > dist[u]) continue;

        for (const Edge& edge : edges[u]) {
            int v = edge.to;
            int weight = edge.weight;

            if (dist[v] > dist[u] + weight) {
                dist[v] = dist[u] + weight;
                pq.push({dist[v], v});
            }
        }
    }
    return dist;
}