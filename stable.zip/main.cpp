#include <iostream>
#include <filesystem>
#include <vector>
#include <string>
#include <fstream>
#include <chrono>
#include <iomanip>
#include "DAG.h"
#include "Instance.h"
#include "Builder.h"

namespace fs = std::filesystem;

std::vector<std::string> get_test_files(const std::string& directory) {
    std::vector<std::string> files;

    for (const auto& entry : fs::directory_iterator(directory)) {
        if (entry.is_regular_file() && entry.path().extension() == ".txt") {
            files.push_back(entry.path().string());
        }
    }

    std::sort(files.begin(), files.end());
    return files;
}

void process_all_tests() {
    std::string tests_dir = "tests_txt";
    std::string results_dir = "results";
    std::string csv_path = results_dir + "/results.csv";

    // Create results directory
    fs::create_directory(results_dir);

    std::ofstream csv_file(csv_path);
    csv_file << "test,N,M,C,total_cost,millis\n";

    std::vector<std::string> test_files = get_test_files(tests_dir);

    for (const auto& test_file : test_files) {
        std::cout << "Processing: " << test_file << std::endl;

        try {
            // Load instance
            TestInstance instance = TestInstance::load_from_file(test_file);

            // Build graph and solve
            auto start = std::chrono::high_resolution_clock::now();
            DAG dag = GraphBuilder::build_from_instance(instance);
            int total_cost = dag.compute_max_flow_min_cost();
            auto end = std::chrono::high_resolution_clock::now();

            auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
            double millis = duration.count() / 1000.0;

            // Get filename only
            std::string filename = fs::path(test_file).filename().string();

            // Write to CSV
            csv_file << filename << ","
                     << instance.N << ","
                     << instance.M << ","
                     << instance.C << ","
                     << total_cost << ","
                     << std::fixed << std::setprecision(3) << millis << "\n";

            std::cout << "  Result: N=" << instance.N << ", M=" << instance.M
                      << ", C=" << instance.C << ", cost=" << total_cost
                      << ", time=" << millis << "ms" << std::endl;

        } catch (const std::exception& e) {
            std::cerr << "  ERROR: " << e.what() << std::endl;
        }
    }

    csv_file.close();
    std::cout << "\nResults saved to: " << csv_path << std::endl;
}

int main() {
    std::cout << "=== Tool Switching Problem Solver ===" << std::endl;
    process_all_tests();
    return 0;
}