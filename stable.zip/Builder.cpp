#include "Builder.h"
#include <vector>
#include <utility>
#include <numeric>
#include <cassert>

using namespace std;

DAG GraphBuilder::build_from_instance(const TestInstance& instance, int K) {
    DAG dag;

    int M = instance.M;
    int N = instance.N;
    int C = instance.C;
    const auto& jobs = instance.job_requirements; // vector<vector<int>>, tools 1-based

    // Build request sequence
    vector<pair<int,int>> reqs;
    for (int r = 0; r < N; ++r) {
        for (int tool : jobs[r]) reqs.emplace_back(r + 1, tool);
    }
    int R = (int)reqs.size();

    // Create vertices: source, C slots, R requests, R copies, sink
    int source = dag.add_vertex(); // 0
    for (int i = 0; i < C; ++i) dag.add_vertex();      // 1..C
    for (int i = 0; i < R; ++i) dag.add_vertex();      // C+1..C+R
    for (int i = 0; i < R; ++i) dag.add_vertex();      // C+R+1..C+2R
    int sink = dag.add_vertex();                       // C+2R+1

    dag.set_source(source);
    dag.set_sink(sink);

    // Build cost matrix D: D[i][j] = 0 if i==j, else instance.tool_costs[j]
    assert((int)instance.tool_costs.size() == M);
    vector<vector<long long>> D(M, vector<long long>(M, 0));
    for (int i = 0; i < M; ++i)
        for (int j = 0; j < M; ++j)
            D[i][j] = (i == j) ? 0 : instance.tool_costs[j];

    // If K not provided (<=0) — сделаем K достаточно большим: сумма абсолютных стоимостей + 1
    if (K <= 0) {
        long long sum = 0;
        for (int i = 0; i < M; ++i)
            for (int j = 0; j < M; ++j)
                sum += llabs(D[i][j]);
        K = (int)(sum + 1);
    }

    // source -> slots (cost 0, cap 1)
    for (int k = 0; k < C; ++k) dag.add_edge(source, 1 + k, 0, 1);

    // slots -> every request (start with empty magazine => cost 0)
    for (int k = 0; k < C; ++k) {
        int slot_node = 1 + k;
        for (int i = 0; i < R; ++i) {
            int req_node = 1 + C + i;
            dag.add_edge(slot_node, req_node, 0, 1);
        }
    }

    // req -> copy: large negative weight -K (горизонтальные рёбра)
    for (int i = 0; i < R; ++i) {
        int req_node = 1 + C + i;
        int copy_node = 1 + C + R + i;
        dag.add_edge(req_node, copy_node, -K, 1);
    }

    // copy -> sink (cost 0)
    for (int i = 0; i < R; ++i) {
        int copy_node = 1 + C + R + i;
        dag.add_edge(copy_node, sink, 0, 1);
    }

    // job_of / tool_of корректно заполнены
    vector<int> job_of(R), tool_of(R);
    for (int i = 0; i < R; ++i) {
        job_of[i] = reqs[i].first;   // 1..N
        tool_of[i] = reqs[i].second; // 1..M
    }

    // copy(i) -> req(j) для всех req в последующих job-группах:
    // cost = D[tool_of[i]-1][tool_of[j]-1]
    for (int i = 0; i < R; ++i) {
        int copy_node = 1 + C + R + i;
        int ti = tool_of[i] - 1;
        for (int j = i + 1; j < R; ++j) {
            if (job_of[j] <= job_of[i]) continue; // только последующие группы
            int req_node = 1 + C + j;
            int tj = tool_of[j] - 1;
            long long cost = D[ti][tj];
            dag.add_edge(copy_node, req_node, cost, 1);
        }
    }

    dag.print();
    return dag;
}
